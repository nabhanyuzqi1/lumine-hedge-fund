import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { DEMO, desk, toast } from '../lib/api'
import { useDesk } from '../lib/useDesk'
import KillSwitchCard from '../components/KillSwitchCard'
import ConfirmDialog from '../components/ConfirmDialog'
import VersionDiffTable from '../components/VersionDiffTable'
import WalkForwardTable from '../components/WalkForwardTable'
import ShadowPanel from '../components/ShadowPanel'
import DegradationPanel from '../components/DegradationPanel'
import ApprovalTimeline from '../components/ApprovalTimeline'
import RiskConfigPanel from '../components/RiskConfigPanel'
import ModeBadge from '../components/ModeBadge'
import ProposalLifecyclePanel from '../components/ProposalLifecyclePanel'
// Panel yang PINDAH dari Ops ke Lab (kartu t_f412fd48): semuanya keputusan
// strategi/riset, bukan operasi harian.
import LlmSettingsPanel from '../components/LlmSettingsPanel'
import SelfImproveApprovalPanel from '../components/SelfImproveApprovalPanel'
import { LlmAgentPanel, ResearchPanel, SupervisorPanel } from '../components/OpsGapPanels'
import { fetchStrategyVersionsDetail, rollbackStrategy } from '../lib/api'

// View yang tersedia per strategi (PRD v2.2 §21.4).
const VIEWS = [
  { id: 'ringkasan', label: 'Ringkasan' },
  { id: 'versi', label: 'Versi & Diff' },
  { id: 'wf', label: 'Walk-forward' },
  { id: 'shadow', label: 'Shadow' },
  { id: 'degradasi', label: 'Degradasi' },
  { id: 'approval', label: 'Approval' },
]

// Statistik strategi berasal dari ledger paper_orders (GET /strategies).
// Mode demo = simulator, jadi badge jujurnya DEMO, bukan PAPER.
const STATS_MODE = DEMO ? 'DEMO' : 'PAPER'

const TRACK_TITLE = {
  A: 'Track A · rule-based',
  B: 'Track B · machine learning',
  C: 'Track C · reinforcement learning',
}

// Angka kosong harus terbaca "tidak ada sampel", bukan 0 yang tampak hasil.
function pct(v, empty) {
  if (empty || v == null || Number.isNaN(Number(v))) return '·'
  return `${(Number(v) * 100).toFixed(1)}%`
}

function dec(v, digits = 2, empty) {
  if (empty || v == null || Number.isNaN(Number(v))) return '·'
  return Number(v).toFixed(digits)
}

function usd(v) {
  if (v == null || Number.isNaN(Number(v))) return '·'
  return `$${Math.round(Number(v)).toLocaleString('id-ID')}`
}

export default function StrategyLab() {
  const state = useDesk()
  const strategies = state?.strategies || []
  const [, setTick] = useState(0)
  // Permintaan fokus dari panel siklus usulan: buka strategi + view Approval.
  const [focus, setFocus] = useState(null)

  useEffect(() => {
    // Real mode: muat daftar strategi dari GET /strategies saat mount
    // (demo sudah mengisi state.strategies dari simulator).
    if (!DEMO) desk.loadStrategies().catch(() => {})
  }, [])

  return (
    <div className="lab">
      <div className="page-head lab-head">
        <div>
          <h1 className="page-title">Strategy Lab</h1>
          <p className="page-sub">Strategi berformat skill · backtest dengan biaya realistis · gerbang paper sebelum live.</p>
        </div>
        <div className="lab-head-meta">
          <ModeBadge mode={STATS_MODE} label={`STATISTIK ${STATS_MODE}`} />
          <span className="chip num" title="Jumlah strategi terdaftar di GET /strategies">{strategies.length} strategi</span>
        </div>
      </div>

      {/* Status saja: aksi arm/flatten/release milik halaman Ops (kartu
          t_f412fd48). Lab tidak lagi punya tombol darurat. */}
      <KillSwitchCard statusOnly />

      {/* Agent LLM: status + pause/resume (dulu di Ops) dan setelannya
          (interval, auto-lot, batas order). Aksi ubah ada di sini, tulis tetap
          lewat kanal Guardrail: password + 2FA + range + audit. */}
      <LlmAgentPanel />
      <LlmSettingsPanel />

      <ProposalLifecyclePanel onOpenStrategy={(id) => setFocus({ id, view: 'approval', nonce: Date.now() })} />

      <section className="card lab-list" aria-label="Daftar strategi">
        <div className="card-head">
          <h2 className="card-title">Strategi</h2>
          <span className="chip" title="Track A: rule-based · Track B: ML · Track C: RL">Track A rule · B ML · C RL</span>
        </div>
        {strategies.length === 0 ? (
          <div className="empty">
            Belum ada strategi terdaftar. Endpoint /strategies di API belum tersedia · daftar akan muncul di sini.
          </div>
        ) : (
          <ul className="lab-strategies">
            {strategies.map((s) => (
              <StrategyRow
                key={s.id}
                s={s}
                focus={focus && focus.id === s.id ? focus : null}
                onChanged={() => setTick((n) => n + 1)}
              />
            ))}
          </ul>
        )}
        <p className="lab-foot">
          Backtest: data 2 tahun per simbol, biaya spread + komisi + slippage termasuk. Hasil backtest bukan jaminan performa.
        </p>
      </section>

      {/* ── Supervisor/lifecycle, riset, approval self-improve ──
          Sebelumnya di halaman Ops (dua tempat untuk satu keputusan).
          Sekarang Lab pemilik aksinya; Ops hanya menautkan ke sini.
          Aksi darurat (arm/flatten/release) tetap milik Ops. */}
      <SupervisorPanel />
      <ResearchPanel />
      <SelfImproveApprovalPanel />
      <p className="lab-foot">
        Aksi darurat kill-switch (stop entry, flatten, release + checklist recovery) ada di{' '}
        <Link className="ia-crosslink" to="/ops">Ops</Link>; angka risiko dan auto-halt ada di{' '}
        <Link className="ia-crosslink" to="/admin/guardrail">Guardrail</Link>.
      </p>
    </div>
  )
}

function StrategyRow({ s, onChanged, focus }) {
  const [open, setOpen] = useState(false)
  const [view, setView] = useState('ringkasan')
  // Data versi dibagi untuk view Versi & Diff dan Walk-forward: sekali muat.
  const [versionsData, setVersionsData] = useState(null)
  const [versionsErr, setVersionsErr] = useState('')
  // Konfirmasi dua langkah untuk mode LIVE (§21.6): konsekuensi + ack + 2FA.
  const [liveOpen, setLiveOpen] = useState(false)
  const [liveBusy, setLiveBusy] = useState(false)
  // Rollback (PRD 11.3): versi tujuan + reason wajib + 2FA.
  const [rollbackTarget, setRollbackTarget] = useState(null)
  const [rollbackReason, setRollbackReason] = useState('')
  const [rollbackBusy, setRollbackBusy] = useState(false)
  const rowRef = useRef(null)

  const needsVersions = open && (view === 'versi' || view === 'wf')

  useEffect(() => {
    if (!needsVersions || versionsData || DEMO) return
    let alive = true
    setVersionsErr('')
    fetchStrategyVersionsDetail(s.id)
      .then((d) => { if (alive) setVersionsData(d) })
      .catch((ex) => { if (alive) setVersionsErr(ex.message) })
    return () => { alive = false }
  }, [needsVersions, versionsData, s.id])

  // Panel siklus usulan hanya punya strategy_id: UI membuka kartu + view
  // Approval strategi yang dimaksud, tanpa mengarang relasi usulan->strategi.
  useEffect(() => {
    if (!focus) return undefined
    setOpen(true)
    setView(focus.view || 'approval')
    const t = setTimeout(() => {
      rowRef.current?.scrollIntoView({ block: 'center', behavior: 'smooth' })
    }, 80)
    return () => clearTimeout(t)
  }, [focus])

  function goLive() {
    setLiveBusy(true)
    desk.setStrategyMode(s.id, 'live')
      .then(() => {
        setLiveOpen(false)
        toast('Mode LIVE aktif', `${s.name} kini order dengan dana nyata`, 'down')
      })
      .catch((ex) => {
        toast('Gagal mengaktifkan mode live', ex.message === 'DEMO' ? 'Tidak tersedia di mode demo' : ex.message, 'down')
      })
      .finally(() => setLiveBusy(false))
  }

  const rollbackReasonOk = rollbackReason.trim().length >= 1

  function doRollback() {
    if (!rollbackTarget || !rollbackReasonOk) return
    setRollbackBusy(true)
    rollbackStrategy(s.id, rollbackTarget.version, rollbackReason.trim())
      .then(() => {
        toast('Rollback berhasil', `Versi aktif ${s.name} kini v${rollbackTarget.version}`, 'up')
        setRollbackTarget(null)
        setRollbackReason('')
        setVersionsData(null) // muat ulang daftar versi (is_current berubah)
        onChanged?.()
      })
      .catch((ex) => toast('Rollback gagal', ex.message, 'down'))
      .finally(() => setRollbackBusy(false))
  }

  const trades = Number(s.trades ?? 0)
  const emptyStats = trades === 0
  const curve = Array.isArray(s.curve) ? s.curve : []
  const lastEquity = curve.length ? curve[curve.length - 1] : s.balance

  return (
    <li className={`lab-strategy ${open ? 'is-open' : ''}`.trim()} ref={rowRef}>
      <div className="lab-strategy-top">
        <div className="lab-strategy-id">
          <div className="lab-chips">
            <span className={`track track-${s.track}`} title={TRACK_TITLE[s.track] || `Track ${s.track}`}>{s.track}</span>
            {s.symbol && <span className="chip" title="Simbol yang diperdagangkan strategi">{s.symbol}</span>}
            {s.lifecycle?.status && (
              <span className="chip lab-lifecycle-chip" title="Status lifecycle strategi (lihat panel Siklus usulan perbaikan)">
                {s.lifecycle.status}
              </span>
            )}
          </div>
          <h3 className="lab-strategy-name">
            <button className="lab-name-btn" type="button" onClick={() => setOpen(!open)} aria-expanded={open}>
              {s.name}
            </button>
          </h3>
          <p className="lab-strategy-desc">{s.desc}</p>
        </div>

        <figure className="lab-figure">
          <EquityCurve curve={curve} />
          <figcaption className="lab-figure-cap">
            <span className="lab-figure-label">Equity paper</span>
            <span className="num">{usd(lastEquity)}</span>
          </figcaption>
        </figure>
      </div>

      <div className="lab-stats" role="group" aria-label={`Statistik ${s.name}`}>
        <div className="lab-stats-lead">
          <ModeBadge mode={STATS_MODE} />
          <span className="lab-stats-hint">statistik ledger paper</span>
        </div>
        <dl className="lab-metrics">
          <div>
            <dt>Winrate</dt>
            <dd className="num">{pct(s.win, emptyStats)}</dd>
          </div>
          <div>
            <dt>Profit factor</dt>
            <dd className="num">{dec(s.pf, 2, emptyStats)}</dd>
          </div>
          <div>
            <dt>Max drawdown</dt>
            <dd className="num down-text">{pct(s.dd, emptyStats)}</dd>
          </div>
          <div>
            <dt>Sharpe</dt>
            <dd className="num">{dec(s.sharpe, 2, emptyStats)}</dd>
          </div>
          <div>
            <dt>Trade tertutup</dt>
            <dd className="num">
              {trades.toLocaleString('id-ID')}
              {emptyStats && <span className="lab-metrics-note">belum ada trade paper</span>}
            </dd>
          </div>
        </dl>
      </div>

      <div className="lab-actions">
        <div className="mode-toggle" role="group" aria-label={`Mode ${s.name}`}>
          <button type="button" className={s.mode === 'paper' ? 'is-active' : ''} aria-pressed={s.mode === 'paper'} onClick={() => desk.setStrategyMode(s.id, 'paper').catch((ex) => toast('Gagal ubah mode', ex.message, 'down'))}>
            Paper
          </button>
          <button type="button" className={`${s.mode === 'live' ? 'is-active' : ''} live-mode-btn`} aria-pressed={s.mode === 'live'} onClick={() => setLiveOpen(true)}>
            Live
          </button>
        </div>
        <button className="btn btn-ghost btn-sm" type="button" onClick={() => setOpen(!open)} aria-expanded={open}>
          {open ? 'Tutup detail' : 'Buka detail'}
        </button>
      </div>

      {open && (
        <div className="lab-detail">
          <div className="lab-views" role="tablist" aria-label={`Panduan detail ${s.name}`}>
            {VIEWS.map((v) => (
              <button
                key={v.id}
                type="button"
                role="tab"
                aria-selected={view === v.id}
                className={`lab-view-btn ${view === v.id ? 'is-active' : ''}`}
                onClick={() => setView(v.id)}
              >
                {v.label}
              </button>
            ))}
          </div>

          <div className="lab-viewpane">
            {view === 'ringkasan' && <SummaryView s={s} />}
            {view === 'versi' && (
              <VersionsView
                data={versionsData}
                err={versionsErr}
                demo={DEMO}
                rollbackBusy={rollbackBusy}
                onRollback={setRollbackTarget}
              />
            )}
            {view === 'wf' && (
              <WalkForwardView data={versionsData} err={versionsErr} demo={DEMO} />
            )}
            {view === 'shadow' && <ShadowView id={s.id} demo={DEMO} />}
            {view === 'degradasi' && <DegradationView id={s.id} demo={DEMO} onChanged={onChanged} />}
            {view === 'approval' && <ApprovalView id={s.id} demo={DEMO} />}
          </div>
        </div>
      )}

      <ConfirmDialog
        open={liveOpen}
        title={`Aktifkan mode LIVE · ${s.name}`}
        description="Strategi ini akan mengirim order ke broker dengan dana nyata."
        consequences={[
          'Order strategi ini memakai dana nyata: rugi/profit mengubah saldo riil',
          'Order tetap melewati risk gate dan kill-switch, tapi gate tidak mencegah rugi pasar',
          'Aktivasi tercatat di audit log sebagai APPROVAL',
        ]}
        ackLabel="Saya paham strategi ini akan berorder dengan dana nyata"
        requires2fa
        confirmLabel="Aktifkan LIVE"
        busy={liveBusy}
        onCancel={() => { if (!liveBusy) setLiveOpen(false) }}
        onConfirm={goLive}
      />

      <ConfirmDialog
        open={!!rollbackTarget}
        title={`Rollback versi · ${s.name}`}
        description={rollbackTarget ? `Versi aktif strategi akan berpindah ke v${rollbackTarget.version}.` : ''}
        consequences={[
          `Entry baru memakai params dan risk_profile versi v${rollbackTarget?.version}`,
          'Posisi terbuka tidak diubah (position policy MANAGE_AS_IS, PRD 11.3)',
          'Peristiwa rollback tercatat append-only di audit log',
        ]}
        ackLabel={rollbackTarget ? `Saya paham versi aktif akan berpindah ke v${rollbackTarget.version}` : ''}
        requires2fa
        confirmLabel={`Rollback ke v${rollbackTarget?.version}`}
        busy={rollbackBusy}
        onCancel={() => { if (!rollbackBusy) { setRollbackTarget(null); setRollbackReason('') } }}
        onConfirm={doRollback}
      >
        <label className="rollback-reason-field">
          <span>Alasan rollback (wajib)</span>
          <textarea
            className={`input rollback-reason ${rollbackReasonOk ? '' : 'rollback-reason-invalid'}`}
            rows={3}
            maxLength={500}
            placeholder="Jelaskan kenapa perlu rollback ke versi ini…"
            value={rollbackReason}
            onChange={(e) => setRollbackReason(e.target.value)}
            disabled={rollbackBusy}
          />
        </label>
      </ConfirmDialog>
    </li>
  )
}

/* ── View: Ringkasan — statistik live dari GET /strategies (tanpa hardcode) ── */
function SummaryView({ s }) {
  const pnl = s.pnl || {}
  return (
    <div className="lab-summary">
      <dl className="lab-summary-rows">
        <div>
          <dt>Mode eksekusi</dt>
          <dd>{s.mode === 'live' ? 'LIVE (dana nyata)' : 'PAPER (simulasi)'}</dd>
        </div>
        <div>
          <dt>Hari paper</dt>
          <dd className="num">{s.paper_days ?? 0} hari</dd>
        </div>
        <div>
          <dt>Saldo paper</dt>
          <dd className="num">{usd(pnl.balance ?? s.balance)}</dd>
        </div>
        <div>
          <dt>P/L terealisasi</dt>
          <dd className={`num ${Number(pnl.realized ?? 0) < 0 ? 'down-text' : Number(pnl.realized ?? 0) > 0 ? 'up-text' : ''}`.trim()}>
            {pnl.realized == null ? '·' : `${Number(pnl.realized) >= 0 ? '+' : ''}$${Number(pnl.realized).toFixed(2)}`}
          </dd>
        </div>
        <div>
          <dt>Trade tertutup</dt>
          <dd className="num">{(s.trades ?? 0).toLocaleString('id-ID')}</dd>
        </div>
        <div>
          <dt>Winrate</dt>
          <dd className="num">{pct(s.win, Number(s.trades ?? 0) === 0)}</dd>
        </div>
        <div>
          <dt>Profit factor</dt>
          <dd className="num">{dec(s.pf, 2, Number(s.trades ?? 0) === 0)}</dd>
        </div>
        <div>
          <dt>Max drawdown</dt>
          <dd className="num down-text">{pct(s.dd, Number(s.trades ?? 0) === 0)}</dd>
        </div>
        <div>
          <dt>Sharpe</dt>
          <dd className="num">{dec(s.sharpe, 2, Number(s.trades ?? 0) === 0)}</dd>
        </div>
        <div>
          <dt>Versi aktif</dt>
          <dd className="num">{s.lifecycle?.current_version ? `v${s.lifecycle.current_version}` : '·'}</dd>
        </div>
        <div>
          <dt>Lifecycle</dt>
          <dd>{s.lifecycle?.status || '·'}</dd>
        </div>
        <div>
          <dt>Breaker</dt>
          <dd>{s.lifecycle?.breaker_state || '·'}</dd>
        </div>
      </dl>
      <RiskConfigPanel strategyId={s.id} />
      <p className="lab-note">
        Statistik dari endpoint /strategies (ledger paper). Gerbang: paper 20 hari sebelum live; biaya spread + komisi + slippage termasuk.
      </p>
    </div>
  )
}

/* ── View: Versi & Diff ── */
function VersionsView({ data, err, demo, rollbackBusy, onRollback }) {
  if (demo) return <DemoNote feature="Versi & diff" />
  if (err) return <p className="vdiff-error" role="alert">{err}</p>
  if (!data) return <p className="eventline-loading">Memuat daftar versi…</p>
  return (
    <VersionDiffTable versions={data.versions || []} onRollback={onRollback} rollbackBusy={rollbackBusy} />
  )
}

/* ── View: Walk-forward (pilih versi, tampilkan report per jendela) ── */
function WalkForwardView({ data, err, demo }) {
  const versions = data?.versions || []
  const [sel, setSel] = useState(-1)

  useEffect(() => {
    // Default: versi aktif, fallback versi terakhir.
    if (!versions.length) { setSel(-1); return }
    const cur = versions.findIndex((v) => v.is_current)
    setSel(cur >= 0 ? cur : versions.length - 1)
  }, [data])

  if (demo) return <DemoNote feature="Walk-forward report" />
  if (err) return <p className="wf-error" role="alert">{err}</p>
  if (!data) return <p className="eventline-loading">Memuat daftar versi…</p>
  if (!versions.length) {
    return <div className="empty">Belum ada versi terdaftar untuk strategi ini.</div>
  }

  return (
    <div className="wf-view">
      <label className="wf-version-pick">
        <span className="text-faint">Versi</span>
        <select className="hf-select" value={sel} onChange={(e) => setSel(Number(e.target.value))} aria-label="Pilih versi untuk walk-forward report">
          {versions.map((v, i) => (
            <option key={v.id ?? v.version} value={i}>
              v{v.version}{v.is_current ? ' (aktif)' : ''}
            </option>
          ))}
        </select>
      </label>
      <WalkForwardTable version={versions[sel]} />
    </div>
  )
}

/* ── View: Shadow ── */
function ShadowView({ id, demo }) {
  if (demo) return <DemoNote feature="Shadow performance" />
  return <ShadowPanel strategyId={id} />
}

/* ── View: Degradasi ── */
function DegradationView({ id, demo, onChanged }) {
  if (demo) return <DemoNote feature="Status degradasi" />
  return <DegradationPanel strategyId={id} onChanged={onChanged} />
}

/* ── View: Approval ── */
function ApprovalView({ id, demo }) {
  if (demo) return <DemoNote feature="Riwayat approval" />
  return <ApprovalTimeline strategyId={id} />
}

function DemoNote({ feature }) {
  return (
    <div className="empty">
      {feature} tidak tersedia di mode demo. Buka tanpa parameter ?demo=1 untuk data dari API.
    </div>
  )
}

// Kanvas equity paper. Warna mengikuti design system (hijau naik / merah
// turun, garis dasar abu). Kurva datar digambar sebagai garis dasar + label
// "flat" supaya tidak terbaca sebagai penurunan.
function EquityCurve({ curve }) {
  const ref = useRef(null)
  useEffect(() => {
    const canvas = ref.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    const w = rect.width
    const h = rect.height
    ctx.clearRect(0, 0, w, h)
    if (!curve?.length) return
    const min = Math.min(...curve)
    const max = Math.max(...curve)
    const flat = max - min < 1e-9
    const x = (i) => (i / Math.max(curve.length - 1, 1)) * w
    const y = (v) => h - 4 - ((v - min) / (max - min || 1)) * (h - 8)
    const up = curve[curve.length - 1] >= curve[0]
    const stroke = flat ? 'rgba(139, 144, 158, 0.65)' : up ? '#10b981' : '#ef4444'

    // Area tipis di bawah garis: memberi volume tanpa mengganggu angka mono.
    if (!flat) {
      ctx.beginPath()
      ctx.moveTo(0, h)
      curve.forEach((v, i) => ctx.lineTo(x(i), y(v)))
      ctx.lineTo(w, h)
      ctx.closePath()
      ctx.fillStyle = up ? 'rgba(16, 185, 129, 0.10)' : 'rgba(239, 68, 68, 0.10)'
      ctx.fill()
    }

    ctx.strokeStyle = stroke
    ctx.lineWidth = flat ? 1 : 1.5
    if (flat) ctx.setLineDash([3, 3])
    ctx.beginPath()
    curve.forEach((v, i) => (i ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v))))
    ctx.stroke()
    ctx.setLineDash([])

    if (!flat) {
      // Titik terakhir: penanda posisi equity terkini.
      ctx.fillStyle = stroke
      ctx.beginPath()
      ctx.arc(x(curve.length - 1), y(curve[curve.length - 1]), 2, 0, Math.PI * 2)
      ctx.fill()
    }

    ctx.fillStyle = 'rgba(139, 144, 158, 0.9)'
    ctx.font = '9px "IBM Plex Mono", monospace'
    ctx.textAlign = 'left'
    ctx.textBaseline = 'top'
    if (flat) {
      ctx.fillText('datar', 2, 2)
    } else {
      ctx.fillText(max.toFixed(0), 2, 2)
      ctx.textAlign = 'right'
      ctx.textBaseline = 'bottom'
      ctx.fillText(min.toFixed(0), w - 2, h - 2)
    }
  }, [curve])
  return <canvas ref={ref} className="equity" width={168} height={44} aria-label="Kurva ekuitas paper backtest" role="img" />
}
