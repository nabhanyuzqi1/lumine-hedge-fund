import PriceChart from '../components/PriceChart'
import OrderForm from '../components/OrderForm'
import PositionsTable from '../components/PositionsTable'
import KillSwitchCard, { EaChip } from '../components/KillSwitchCard'
import SystemMetrics from '../components/SystemMetrics'
import RegimeCard from '../components/RegimeCard'
import AlertsStrip from '../components/AlertsStrip'
import ActiveStrategyChip from '../components/ActiveStrategyChip'
import { SessionBadges } from '../components/OrderForm'
import { useDesk, DEMO } from '../lib/useDesk'
import { auth, desk, fetchRiskPortfolio } from '../lib/api'
import { SYMBOLS } from '../lib/market'
import ModeBadge, { ModeLegend } from '../components/ModeBadge'
import { ActiveRiskConfig } from '../components/RiskConfigPanel'
import { useEffect, useState } from 'react'

// Mode data uang di terminal: /positions + /positions equity = akun broker
// nyata (LIVE). Di mode demo, angka berasal dari simulator -> DEMO.
const DATA_MODE = DEMO ? 'DEMO' : 'LIVE'

const TF = [
  { id: '1m', label: '1m', n: 1 },
  { id: '5m', label: '5m', n: 5 },
  { id: '15m', label: '15m', n: 15 },
  { id: '1h', label: '1h', n: 60 },
]

// Indikator stale umum (PRD §21.2): quote > 60s tanpa tick baru = STALE.
const QUOTE_STALE_S = 60

function aggregate(ticks, n) {
  if (!ticks || n === 1) return ticks
  const out = []
  for (let i = 0; i < ticks.length; i += n) {
    const slice = ticks.slice(i, i + n)
    out.push(slice.reduce((a, b) => a + b, 0) / slice.length)
  }
  return out
}

// Usia tick terakhir simbol aktif (detik), diperbarui tiap detik.
// Sumber: desk.onTick (SSE) — bukan mock; 0 tick = null.
function useTickAge(symbol) {
  const [age, setAge] = useState(null)
  useEffect(() => {
    let last = null
    const off = auth.onTick((t) => {
      if (!symbol || t.symbol === symbol) last = Date.now()
    })
    const timer = setInterval(() => {
      setAge(last == null ? null : (Date.now() - last) / 1000)
    }, 1000)
    return () => { off(); clearInterval(timer) }
  }, [symbol])
  return age
}

// Widget Portfolio risk (PRD v2.2 §7/§21.2, UI-D1): total open risk
// (worst-case loss), margin terpakai + sumber, eksposur, dan daftar
// limit yang dilewati (breaches, teks merah). Data GET /risk/portfolio;
// 2x poll (60s) tanpa data baru -> STALE.
const RISK_POLL_MS = 30000
const RISK_STALE_MS = 2 * RISK_POLL_MS

function PortfolioRiskCard() {
  const [snap, setSnap] = useState(null)
  const [err, setErr] = useState(null)
  const [lastOk, setLastOk] = useState(null)
  const [now, setNow] = useState(Date.now())

  useEffect(() => {
    let alive = true
    async function poll() {
      try {
        const body = await fetchRiskPortfolio()
        if (alive) { setSnap(body); setErr(null); setLastOk(Date.now()) }
      } catch (ex) {
        if (alive) setErr(ex.message)
      }
    }
    poll()
    const t = setInterval(poll, RISK_POLL_MS)
    const tick = setInterval(() => setNow(Date.now()), 1000)
    return () => { alive = false; clearInterval(t); clearInterval(tick) }
  }, [])

  const stale = lastOk != null && now - lastOk > RISK_STALE_MS
  const ageS = lastOk != null ? Math.round((now - lastOk) / 1000) : null
  const breaches = Array.isArray(snap?.breaches) ? snap.breaches : []
  const usd = (v) => (v == null ? '·' : `$${Math.round(v).toLocaleString('id-ID')}`)

  return (
    <section className={`card risk-card ${stale ? 'stale' : ''}`} aria-label="Portfolio risk">
      <div className="card-head">
        <h2 className="card-title">Portfolio risk</h2>
        {err
          ? <span className="chip chip-down">
              {lastOk != null ? `RISK OFFLINE · STALE (umur ${ageS}s)` : 'RISK OFFLINE'}
            </span>
          : stale && <span className="chip chip-gold">STALE (umur {ageS}s)</span>}
      </div>
      {!snap ? (
        <p className="sm-empty">{err ? `Gagal memuat portfolio risk: ${err}` : 'Memuat portfolio risk…'}</p>
      ) : (
        <div className="risk-body">
          <div className="risk-row">
            <span className="sm-label">Open risk (worst-case)</span>
            <span className="sm-value num">{usd(snap.open_risk_usd)}</span>
          </div>
          <div className="risk-row">
            <span className="sm-label">Stress risk</span>
            <span className="sm-value num">{usd(snap.stress_risk_usd)}</span>
          </div>
          <div className="risk-row">
            <span className="sm-label">Margin terpakai</span>
            <span className="sm-value num">
              {usd(snap.margin_used_usd)}
              {snap.margin_utilization_pct != null && ` (${snap.margin_utilization_pct.toFixed(1)}%)`}
            </span>
          </div>
          <div className="risk-row">
            <span className="sm-label">Eksposur bruto</span>
            <span className="sm-value num">{usd(snap.gross_exposure_usd)}</span>
          </div>
          <div className="risk-row">
            <span className="sm-label">
              Equity <ModeBadge mode={DATA_MODE} />
            </span>
            <span className="sm-value num">{usd(snap.equity)}</span>
          </div>
          <div className="risk-row">
            <span className="sm-label">Posisi / pending / sent</span>
            <span className="sm-value num">
              {snap.open_positions ?? '·'} / {snap.pending_orders ?? '·'} / {snap.sent_orders ?? '·'}
            </span>
          </div>
          {breaches.length > 0 && (
            <div className="risk-breaches" role="alert">
              {breaches.map((b) => <span key={b} className="breach-item">⚠ {b}</span>)}
            </div>
          )}
        </div>
      )}
    </section>
  )
}

// Pemilih simbol (multipair): mengubah state.symbol global sehingga harga,
// spread, grafik, sesi, form order, dan rekap posisi ikut berpindah tanpa reload.
function SymbolPicker({ value }) {
  return (
    <div className="tf-group symbol-picker" role="group" aria-label="Pilih simbol">
      {Object.keys(SYMBOLS).map((s) => (
        <button
          key={s}
          type="button"
          className={`tf-btn ${s === value ? 'is-active' : ''}`}
          aria-pressed={s === value}
          onClick={() => desk.setSymbol(s)}
        >
          {s}
        </button>
      ))}
    </div>
  )
}

export default function Dashboard() {
  const state = useDesk()
  const [tf, setTf] = useState('1m')
  const symbol = state?.symbol
  const quote = symbol ? state?.quotes?.[symbol] : null
  const data = aggregate(quote?.ticks, TF.find((t) => t.id === tf)?.n || 1)
  const tickAge = useTickAge(symbol)
  const quoteStale = tickAge != null && tickAge > QUOTE_STALE_S

  const hasTicks = Array.isArray(data) && data.length > 1

  return (
    <div className="dashboard">
      {/* Strip alert aktif (UI-D1): paling atas agar SEV langsung terlihat */}
      <AlertsStrip />

      {/* Slot PnlHero (UI-D4): hero P&L hari ini + badge mode menggantikan
          SystemMetrics sebagai blok pertama setelah AlertsStrip. Tidak
          diimplementasikan di kartu UI-D2. */}

      {/* Strip instrumen (referensi Live Terminal): pemilih simbol, quote
          BID/ASK/SPREAD, sesi, status EA, dan status feed. */}
      <div className="dash-strip">
        <div className="dash-symbol">
          <SymbolPicker value={symbol} />
          <span className={`dash-price num ${quoteStale ? 'stale' : ''}`}>
            {quote?.price?.toFixed(2) ?? '·····'}
          </span>
          {quoteStale && <span className="chip chip-warn stale-label">STALE · {Math.round(tickAge)}s</span>}
          {DEMO && <span className="demo-badge">DEMO</span>}
        </div>
        <div className="dash-meta">
          {/* F-UI-3: bid/ask dari tick yang sama dengan harga headline (mid).
              Form order memakai ask/bid dari snapshot ini juga, sehingga
              selisih headline vs form (= spread/2) bisa ditelusuri. */}
          <span className={`quote-pair ${quoteStale ? 'stale' : ''}`} title="Bid / ask tick terakhir">
            <span className="qp-label down-text">BID</span>
            <span className="qp-num num">{quote?.bid != null ? quote.bid.toFixed(2) : '·'}</span>
            <span className="qp-sep" aria-hidden="true" />
            <span className="qp-label up-text">ASK</span>
            <span className="qp-num num">{quote?.ask != null ? quote.ask.toFixed(2) : '·'}</span>
            <span className="qp-sep" aria-hidden="true" />
            <span className="qp-label">SPREAD</span>
            <span className="qp-num num">{quote?.spread != null ? quote.spread.toFixed(2) : '·'}</span>
          </span>
          <SessionBadges sessions={quote?.sessions} />
          <EaChip />
          <span className={`chip ${state?.connection === 'live' ? 'chip-up' : 'chip-warn'}`}>
            <i className="chip-dot" aria-hidden="true" />
            {state?.connection === 'live' ? 'LIVE' : state?.connection === 'demo' ? 'SIMULASI' : '…'}
          </span>
        </div>
      </div>

      {/* Baris utama: chart (74%) + rel pengaman (kill-switch + order gate).
          Struktur mengikuti referensi Live Terminal; hirarki P&L menyusul UI-D4. */}
      <div className="dash-main">
        <section className="card dash-chart" aria-label={`Grafik harga ${symbol ?? ''}`}>
          <div className="card-head">
            <h2 className="card-title">
              Harga <span className="card-title-dim">· {symbol ?? '·····'}</span>
            </h2>
            <div className="dash-chart-tools">
              <span className="chart-caption num">{TF.find((t) => t.id === tf)?.label} · mid (bid+ask)/2</span>
              <div className="tf-group" role="group" aria-label="Timeframe">
                {TF.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    className={`tf-btn ${tf === t.id ? 'is-active' : ''}`}
                    aria-pressed={tf === t.id}
                    onClick={() => setTf(t.id)}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
          {hasTicks ? (
            <PriceChart ticks={data} height={360} symbol={symbol} />
          ) : (
            <div className="chart-empty" style={{ height: 360 }}>
              <span className="chart-empty-dot" aria-hidden="true" />
              <p>Menunggu tick {symbol ?? 'pasar'} pertama dari feed.</p>
              <span className="chart-empty-note num">
                Grafik hanya menggambar data live; tidak ada deret sintetis.
              </span>
            </div>
          )}
        </section>

        <aside className="dash-rail" aria-label="Kontrol eksekusi">
          <KillSwitchCard />
          <OrderForm />
        </aside>
      </div>

      {/* Baris audit-review UI-D1: regime + portfolio risk berdampingan. */}
      <div className="dash-audit-grid">
        <RegimeCard symbol={symbol} />
        <PortfolioRiskCard />
      </div>

      {/* UI-D3c: legenda arti badge mode + panel plafon risiko efektif.
          Breaches tetap ditampilkan PortfolioRiskCard di atas; panel ini
          menampilkan ANGKA plafon + batas agent, bukan duplikat alert. */}
      <ModeLegend className="dash-legend" />
      <ActiveRiskConfig />

      <ActiveStrategyChip />

      {/* System metrics: 1 import + 1 pemanggilan agar mudah dilepas UI-D4. */}
      <SystemMetrics />

      <PositionsTable />
    </div>
  )
}
