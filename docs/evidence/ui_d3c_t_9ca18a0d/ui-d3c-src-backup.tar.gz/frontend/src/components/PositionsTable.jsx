import { desk, toast } from '../lib/api'
import { DEMO, useDesk } from '../lib/useDesk'
import ModeBadge from './ModeBadge'

// Guard sel numerik: API bisa mengirim null/undefined (sl/tp) — jangan panggil toFixed.
const num = (v) => (v == null || Number.isNaN(Number(v)) ? '·' : Number(v).toFixed(2))

// Mode data baris posisi: /positions adalah snapshot broker. Di mode demo
// angka berasal dari simulator, jadi badge-nya DEMO (bukan LIVE).
const DATA_MODE = DEMO ? 'DEMO' : 'LIVE'

function Pnl({ value, className = '' }) {
  const n = value == null ? NaN : Number(value)
  const cls = Number.isNaN(n) ? '' : n >= 0 ? 'up-text' : 'down-text'
  return (
    <span className={`num ${className} ${cls}`.trim()}>
      {Number.isNaN(n) ? '·' : `${n >= 0 ? '+' : ''}$${n.toFixed(2)}`}
    </span>
  )
}

// Sumber posisi (UI-D3c): posisi broker tidak membawa nama strategi, hanya
// order_id. Join ke state.orders (dimuat bersamaan di desk.refresh) untuk
// membaca field `strategy` order asalnya. Tidak ada order yang cocok =
// posisi warisan / dibuka langsung EA, dan itu dikatakan apa adanya.
function strategyOf(p, ordersById) {
  const key = p.orderId == null ? null : String(p.orderId)
  const order = key ? ordersById.get(key) : null
  if (!order) {
    return {
      label: 'Tidak diketahui (warisan/EA langsung)',
      unknown: true,
      title: p.orderId
        ? `order_id ${p.orderId} tidak ada di state.orders (warisan / dibuka langsung oleh Bridge EA)`
        : 'Posisi tanpa order_id (warisan / dibuka langsung oleh Bridge EA)',
    }
  }
  const raw = String(order.strategy ?? '').trim()
  const isManual = raw === '' || raw === 'manual'
  return {
    label: isManual ? 'Manual' : raw,
    manual: isManual,
    title: `order_id ${key} · strategi ${isManual ? 'manual (tombol Order Baru / UI)' : raw} · sumber data: Bridge EA (snapshot /positions)`,
  }
}

// Rekap multipair: satu baris agregat per simbol + baris total semua simbol.
// Tanpa badge, chip P/L akan terbaca sebagai uang nyata tanpa konteks sumber.
function Aggregates({ positions }) {
  const bySymbol = new Map()
  let totalCount = 0
  let totalPnl = 0
  for (const p of positions) {
    const sym = p.symbol || '—'
    const pnl = p.pnl == null ? 0 : Number(p.pnl)
    const a = bySymbol.get(sym) || { symbol: sym, count: 0, pnl: 0 }
    a.count += 1
    a.pnl += pnl
    bySymbol.set(sym, a)
    totalCount += 1
    totalPnl += pnl
  }
  return (
    <div className="pos-agg" role="list" aria-label="Rekap posisi per simbol">
      <span className="pos-agg-lead">
        P/L agregat <ModeBadge mode={DATA_MODE} />
      </span>
      {[...bySymbol.values()].map((a) => (
        <span key={a.symbol} className="chip" role="listitem" title={`Total P/L ${a.symbol} dari ${a.count} posisi terbuka`}>
          <strong>{a.symbol}</strong>
          <span className="text-faint">{a.count} pos</span>
          <Pnl value={a.pnl} />
        </span>
      ))}
      <span className="chip chip-gold" role="listitem" title={`Total P/L semua simbol dari ${totalCount} posisi terbuka`}>
        <strong>Total</strong>
        <span className="text-faint">{totalCount} pos</span>
        <Pnl value={totalPnl} />
      </span>
    </div>
  )
}

export default function PositionsTable() {
  const state = useDesk()
  // F-UI-1: GET /positions mengirim semua status (OPEN dulu). Dashboard hanya
  // menampilkan OPEN — chip hitung, baris, dan tombol Tutup memakai daftar
  // yang sama. Baris tanpa status (mode demo) dianggap OPEN. Riwayat tetap
  // menampilkan yang CLOSED karena memakai /orders, bukan /positions.
  const positions = (state?.positions || []).filter((p) => (p.status ?? 'OPEN') === 'OPEN')
  // Indeks order untuk join sumber posisi (order.strategy). Dibangun sekali
  // per render dari state yang sama; tidak ada request tambahan.
  const ordersById = new Map((state?.orders || []).map((o) => [String(o.id), o]))

  async function close(id) {
    try {
      await desk.closePosition(id)
      toast('Posisi ditutup', id)
    } catch (ex) {
      toast('Gagal menutup', ex.message, 'down')
    }
  }

  return (
    <section className="card" aria-label="Posisi terbuka">
      <div className="card-head">
        <h2 className="card-title">Posisi terbuka</h2>
        <div className="pos-head-meta">
          <ModeBadge mode={DATA_MODE} />
          <span className="chip">{positions.length} aktif</span>
        </div>
      </div>
      {positions.length === 0 ? (
        <div className="empty">Tidak ada posisi terbuka. Order terisi akan muncul di sini realtime.</div>
      ) : (
        <>
          <Aggregates positions={positions} />
          <div className="table-wrap">
            <table className="data positions-table">
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Simbol</th>
                  <th>Strategi</th>
                  <th>Mode</th>
                  <th>Arah</th>
                  <th className="num">Volume</th>
                  <th className="num">Entry</th>
                  <th className="num">SL</th>
                  <th className="num">TP</th>
                  <th className="num">P/L</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {positions.map((p) => {
                  const src = strategyOf(p, ordersById)
                  return (
                    <tr key={p.id}>
                      <td className="num text-faint" title={src.title}>{p.orderId ?? '·'}</td>
                      <td className="text-faint">{p.symbol ?? '·'}</td>
                      <td>
                        <span className={`pos-strategy ${src.unknown ? 'is-unknown' : ''}`.trim()} title={src.title}>
                          {src.label}
                        </span>
                      </td>
                      <td>
                        <ModeBadge mode={DATA_MODE} />
                      </td>
                      <td>
                        <span className={`chip ${p.side === 'buy' ? 'chip-up' : 'chip-down'}`}>
                          {p.side === 'buy' ? 'BELI' : 'JUAL'}
                        </span>
                      </td>
                      <td className="num">{num(p.volume)}</td>
                      <td className="num">{num(p.entry)}</td>
                      <td className="num down-text">{num(p.sl)}</td>
                      <td className="num up-text">{num(p.tp)}</td>
                      <td className="num">
                        <Pnl value={p.pnl} />
                      </td>
                      <td className="cell-action">
                        <button className="btn btn-ghost btn-close" onClick={() => close(p.id)} type="button">
                          Tutup
                        </button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
          <div className="positions-cards">
            {positions.map((p) => {
              const src = strategyOf(p, ordersById)
              return (
                <div className="pcard" key={p.id}>
                  <div className="pcard-top">
                    <span className={`chip ${p.side === 'buy' ? 'chip-up' : 'chip-down'}`}>{p.side === 'buy' ? 'BELI' : 'JUAL'}</span>
                    <span className="chip">{p.symbol ?? '·'}</span>
                    <ModeBadge mode={DATA_MODE} />
                    <Pnl value={p.pnl} className="pcard-pnl" />
                  </div>
                  <div className="pcard-src" title={src.title}>
                    <span className="pcard-src-label">Strategi</span>
                    <span className={`pos-strategy ${src.unknown ? 'is-unknown' : ''}`.trim()}>{src.label}</span>
                  </div>
                  <p className="pcard-order num text-faint" title={src.title}>order {p.orderId ?? '·'} · sumber Bridge EA</p>
                  <div className="pcard-grid num">
                    <span>{num(p.volume)} lot</span>
                    <span>entry {num(p.entry)}</span>
                    <span className="down-text">SL {num(p.sl)}</span>
                    <span className="up-text">TP {num(p.tp)}</span>
                  </div>
                  <button className="btn btn-ghost btn-close" onClick={() => close(p.id)} type="button">
                    Tutup posisi
                  </button>
                </div>
              )
            })}
          </div>
        </>
      )}
    </section>
  )
}
