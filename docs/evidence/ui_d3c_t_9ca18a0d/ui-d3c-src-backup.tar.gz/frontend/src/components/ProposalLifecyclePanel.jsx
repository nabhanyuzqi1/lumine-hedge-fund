// UI-D3c · panel "Siklus Usulan Perbaikan" di Strategy Lab.
//
// Dua sisi berdampingan, sumber data REAL (tidak ada relasi karangan):
//   1. Pipeline usulan: GET /improve/proposals -> {proposals:[{id, week, title,
//      verdict, status, reviewer, decided_at, deployed_at}]} (PROPOSED ->
//      APPROVED/REJECTED -> DEPLOYED).
//   2. Lifecycle strategi: GET /strategies/lifecycle-summary
//      -> {strategies:[{strategy_id, name, lifecycle_status, active_version,
//      version_count, last_approval_stage, last_approval_decision,
//      degradation_status, has_walkforward, has_shadow}]}.
//
// PENTING: respons /improve/proposals TIDAK memuat strategy_id. Panel ini
// sengaja TIDAK menggambar panah relasi usulan->strategi; kolom kiri
// (keputusan/deploy) dan kolom kanan (strategi + versi aktif) dibaca
// berdampingan supaya rantainya tetap terlihat tanpa mengarang relasi.
import { useEffect, useState } from 'react'
import { DEMO, desk, fetchLifecycleSummary } from '../lib/api'

// Status pipeline usulan -> nada warna semantik (bukan dekorasi).
const PROPOSAL_TONE = {
  PROPOSED: 'warn',
  APPROVED: 'up',
  REJECTED: 'down',
  DEPLOYED: 'up',
}

// Lifecycle strategi (PRD 5.3). Status tak dikenal tetap ditampilkan apa adanya.
const LIFECYCLE_TONE = {
  DRAFT: 'mute',
  PAPER: 'mute',
  SHADOW: 'warn',
  LIVE_APPROVED: 'up',
  LIVE: 'up',
  PAUSED: 'warn',
  HALTED: 'down',
  RETIRED: 'down',
}

function fmtTime(iso) {
  if (!iso) return ''
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return String(iso)
  return d.toLocaleString('id-ID', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

function StatusChip({ status, tones, className = '' }) {
  const key = String(status || '').toUpperCase()
  const tone = tones[key] || 'mute'
  return (
    <span className={`chip lc-chip lc-chip-${tone} ${className}`.trim()} title={`Status ${key || 'tidak diketahui'}`}>
      {key || '—'}
    </span>
  )
}

function MockNote({ children }) {
  return <div className="empty lifecycle-empty">{children}</div>
}

export default function ProposalLifecyclePanel({ onOpenStrategy }) {
  const [proposals, setProposals] = useState(null)
  const [propErr, setPropErr] = useState('')
  const [summary, setSummary] = useState(null)
  const [sumErr, setSumErr] = useState('')

  useEffect(() => {
    if (DEMO) return undefined
    let alive = true
    desk.proposals()
      .then((d) => {
        if (!alive) return
        setProposals(Array.isArray(d?.proposals) ? d.proposals : [])
      })
      .catch((ex) => { if (alive) setPropErr(ex.message) })
    fetchLifecycleSummary()
      .then((d) => {
        if (!alive) return
        setSummary(Array.isArray(d?.strategies) ? d.strategies : [])
      })
      .catch((ex) => { if (alive) setSumErr(ex.message) })
    return () => { alive = false }
  }, [])

  const pipeline = proposals || []
  const rows = summary || []

  return (
    <section className="card lifecycle" aria-label="Siklus usulan perbaikan">
      <div className="card-head">
        <h2 className="card-title lifecycle-title">Siklus usulan perbaikan</h2>
        <div className="lifecycle-counts">
          <span className="chip" title="Panel ringkasan baca-saja. Aksi approve/reject ada di panel Approval self-improve di bagian bawah halaman.">
            baca-saja
          </span>
          {proposals && (
            <span className="chip num" title="Jumlah usulan self-improve tercatat di GET /improve/proposals">
              {pipeline.length} usulan
            </span>
          )}
          {summary && (
            <span className="chip num" title="Jumlah strategi terdaftar di lifecycle-summary">
              {rows.length} strategi
            </span>
          )}
        </div>
      </div>

      <div className="lifecycle-grid">
        <div className="lifecycle-col" aria-label="Pipeline usulan">
          <h3 className="lifecycle-col-title">
            Pipeline usulan <span className="lifecycle-col-src num">GET /improve/proposals</span>
          </h3>
          {DEMO ? (
            <MockNote>Pipeline usulan tidak tersedia di mode demo. Buka tanpa <code>?demo=1</code> untuk data API.</MockNote>
          ) : propErr ? (
            <p className="lifecycle-error" role="alert">{propErr}</p>
          ) : !proposals ? (
            <p className="eventline-loading">Memuat usulan…</p>
          ) : pipeline.length === 0 ? (
            <MockNote>Belum ada usulan self-improve tercatat.</MockNote>
          ) : (
            <ol className="pipe-list">
              {pipeline.map((p) => {
                const decided = fmtTime(p.decided_at)
                const deployed = fmtTime(p.deployed_at)
                const verdictUp = String(p.verdict || '').toUpperCase() === 'LULUS'
                return (
                  <li className="pipe-item" key={p.id}>
                    <div className="pipe-line">
                      <span className="pipe-week num">{p.week || '—'}</span>
                      <StatusChip status={p.status} tones={PROPOSAL_TONE} />
                      {p.verdict && (
                        <span className={`pipe-verdict ${verdictUp ? 'up-text' : 'down-text'}`} title="Hasil evaluasi (verdict) usulan, bukan status pipeline">
                          verdict {p.verdict}
                        </span>
                      )}
                    </div>
                    <p className="pipe-title">{p.title}</p>
                    <p className="pipe-meta">
                      <span title="Reviewer keputusan owner">{p.reviewer || 'reviewer —'}</span>
                      <span className="pipe-dot" aria-hidden="true">·</span>
                      <span>{decided ? `diputuskan ${decided}` : 'belum diputuskan'}</span>
                      <span className="pipe-dot" aria-hidden="true">·</span>
                      <span className={deployed ? 'up-text' : 'pipe-meta-mute'}>
                        {deployed ? `deploy ${deployed}` : 'belum deploy'}
                      </span>
                    </p>
                    <p className="pipe-id num" title="ID usulan (prefix -p1/-p2 dst = urutan usulan dalam gelombang)">{p.id}</p>
                  </li>
                )
              })}
            </ol>
          )}
        </div>

        <div className="lifecycle-col" aria-label="Lifecycle strategi">
          <h3 className="lifecycle-col-title">
            Lifecycle strategi <span className="lifecycle-col-src num">GET /strategies/lifecycle-summary</span>
          </h3>
          {DEMO ? (
            <MockNote>Ringkasan lifecycle tidak tersedia di mode demo. Buka tanpa <code>?demo=1</code> untuk data API.</MockNote>
          ) : sumErr ? (
            <p className="lifecycle-error" role="alert">{sumErr}</p>
          ) : !summary ? (
            <p className="eventline-loading">Memuat lifecycle strategi…</p>
          ) : rows.length === 0 ? (
            <MockNote>Belum ada strategi terdaftar.</MockNote>
          ) : (
            <ul className="lc-list">
              {rows.map((s) => (
                <li className="lc-item" key={s.strategy_id}>
                  <div className="lc-head">
                    <span className="lc-name">{s.name || s.strategy_id}</span>
                    <StatusChip status={s.lifecycle_status} tones={LIFECYCLE_TONE} />
                    <span className="chip lc-chip lc-chip-mute" title="Status degradasi (PRD §10)">
                      DD {s.degradation_status || 'NORMAL'}
                    </span>
                  </div>
                  <div className="lc-meta">
                    <span title="Versi yang sedang aktif dipakai strategi">
                      Aktif <strong className="num">{s.active_version ? `v${s.active_version}` : '—'}</strong>
                    </span>
                    <span title="Jumlah versi yang terdaftar di registry versi (0 = belum pernah submit versi)">
                      Registry <strong className="num">{s.version_count ?? 0} versi</strong>
                    </span>
                    <span title="Stage dan keputusan approval terakhir">
                      Approval{' '}
                      <strong>
                        {s.last_approval_stage
                          ? `${s.last_approval_stage} · ${s.last_approval_decision || '—'}`
                          : 'belum ada'}
                      </strong>
                    </span>
                  </div>
                  <div className="lc-foot">
                    <span className="lc-signals" title="Kesiapan bukti: walk-forward report dan shadow run">
                      WF <strong>{s.has_walkforward ? 'ada' : 'belum'}</strong> · Shadow{' '}
                      <strong>{s.has_shadow ? 'ada' : 'belum'}</strong>
                    </span>
                    {onOpenStrategy && (
                      <button
                        type="button"
                        className="lc-link"
                        onClick={() => onOpenStrategy(s.strategy_id)}
                        title={`Buka view Approval strategi ${s.name || s.strategy_id}`}
                      >
                        Lihat approval
                      </button>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <p className="lifecycle-foot">
        Alur: usulan riset → keputusan owner (2FA) → deploy → strategi + versi aktif. Kedua sisi ditampilkan
        berdampingan karena <code>GET /improve/proposals</code> tidak memuat <code>strategy_id</code>; relasi
        usulan → strategi tidak dikarang di UI.
      </p>
    </section>
  )
}
