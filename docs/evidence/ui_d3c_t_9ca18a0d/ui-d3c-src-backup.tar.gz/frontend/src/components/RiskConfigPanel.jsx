import { useEffect, useState } from 'react'
import { DEMO, fetchLlmStatus, fetchRiskPortfolio, fetchStrategyRiskConfigs } from '../lib/api'

/* ── RISK-D (t_a172bb7b): panel config risk per strategi di Strategy Lab.
   Menampilkan nilai EFEKTIF (merge global + override) dan sumbernya supaya
   operator tahu nilai mana yang mengetatkan config global. Read-only: semua
   perubahan lewat alur approval owner (propose -> decision 2FA). */

const SRC_LABEL = {
  global: 'global',
  override: 'override',
  override_capped: 'override (dibatasi global)',
}

function fmtValue(key, value) {
  if (value === null || value === undefined) return '—'
  if (key === 'be_buffer') {
    const entries = Object.entries(value || {})
    if (!entries.length) return '—'
    return entries.map(([sym, v]) => `${sym} ${Number(v).toFixed(2)}`).join(' · ')
  }
  const n = Number(value)
  if (!Number.isFinite(n)) return String(value)
  if (key === 'risk_pct') return `${n}%`
  if (key === 'max_positions') return `${n} posisi`
  if (key === 'daily_loss_limit') return `$${n.toLocaleString('id-ID')}`
  if (key === 'be_trigger_r' || key === 'trail_activate_r') return `${n}R`
  if (key === 'trail_atr_mult') return `${n}× ATR`
  return String(n)
}

export default function RiskConfigPanel({ strategyId }) {
  const [data, setData] = useState(null)
  const [err, setErr] = useState('')

  useEffect(() => {
    if (DEMO) return undefined
    let alive = true
    setErr('')
    fetchStrategyRiskConfigs()
      .then((d) => {
        if (!alive) return
        const row = (d.strategies || []).find((s) => s.strategy_id === strategyId)
        setData(row ? { ...row, keys: d.keys || [], global: d.global } : null)
      })
      .catch((ex) => { if (alive) setErr(ex.message) })
    return () => { alive = false }
  }, [strategyId])

  if (DEMO) {
    return <p className="text-faint">Config risk per strategi hanya tersedia di mode real.</p>
  }
  if (err) return <p className="text-faint" role="alert">{err}</p>
  if (!data) return <p className="text-faint">Memuat config risk…</p>

  return (
    <section className="risk-config" aria-label={`Config risk efektif ${strategyId}`}>
      <h4 className="card-title">Risk per strategi (efektif)</h4>
      <dl className="dialog-rows">
        {(data.keys || []).map((k) => {
          const src = (data.sources || {})[k.key] || 'global'
          return (
            <div className="dialog-row" key={k.key}>
              <dt>{k.label}</dt>
              <dd className="num">
                {fmtValue(k.key, (data.effective || {})[k.key])}{' '}
                <span
                  className={`chip ${src === 'global' ? '' : 'chip-gold'}`}
                  title={`sumber: ${SRC_LABEL[src] || src}`}
                >
                  {SRC_LABEL[src] || src}
                </span>
              </dd>
            </div>
          )
        })}
      </dl>
      {data.pending && (
        <p className="text-faint">
          Usulan perubahan menunggu keputusan owner (request #{data.pending.id}).
        </p>
      )}
      <p className="text-faint">
        Nilai efektif = merge(global, override). Global adalah batas atas: override
        hanya boleh mengetatkan, dan perubahan lewat approval owner (2FA) + audit log.
      </p>
    </section>
  )
}

/* ── UI-D3c · Panel "Risk config aktif" untuk Dashboard ─────────────────────
   Sumber read-only yang sudah ada di backend (tidak ada endpoint baru):
     GET /risk/portfolio -> snap.limits (plafon portofolio efektif) + breaches
     GET /llm-agent/status -> llm_risk (batas agent), pause, stats,
                              daily_drawdown_pct (nilai berjalan)
   Catatan jujur: `allowed_symbols` dan `exposure_max_usd` hanya ada di
   settings backend dan TIDAK diekspos endpoint read-only mana pun; baris itu
   ditampilkan sebagai "tidak terekspos via API", bukan angka karangan.
   Butuh endpoint backend mikro terpisah untuk menampilkannya. */

const RISK_POLL_MS = 30000
const RISK_STALE_MS = 2 * RISK_POLL_MS

// label, satuan, jumlah desimal
const LIMIT_ROWS = [
  ['max_risk_per_trade_pct', 'Risiko per trade', '%', 1],
  ['max_open_risk_pct', 'Total open risk', '%', 1],
  ['stress_max_risk_pct', 'Stress scenario', '%', 1],
  ['max_total_volume_lot', 'Volume total maks', 'lot', 2],
  ['max_margin_utilization_pct', 'Margin utilization', '%', 1],
  ['max_symbol_risk_pct', 'Risiko per simbol', '%', 1],
  ['leverage', 'Leverage', '×', 0],
]

const LLM_ROWS = [
  ['max_orders_per_min', 'Order maks / menit', '×', 0],
  ['max_orders_per_day', 'Order maks / hari', '×', 0],
  ['cooldown_s', 'Jeda antar order', 's', 0],
  ['drawdown_pause_pct', 'Pause di drawdown', '%', 1],
  ['consecutive_failed_pause', 'Pause setelah FAILED beruntun', '×', 0],
]

function fmtNum(value, digits) {
  if (value == null || value === '' || Number.isNaN(Number(value))) return '·'
  const n = Number(value)
  return digits === 0 ? String(Math.round(n)) : n.toFixed(digits)
}

function RiskRow({ label, value, unit, muted, hint }) {
  return (
    <div className={`rca-row ${muted ? 'rca-row-muted' : ''}`.trim()}>
      <dt>{label}</dt>
      <dd className="num" title={hint || undefined}>
        {value}
        {unit && !muted && <span className="rca-unit">{unit}</span>}
      </dd>
    </div>
  )
}

export function ActiveRiskConfig() {
  const [snap, setSnap] = useState(null)
  const [llm, setLlm] = useState(null)
  const [errSnap, setErrSnap] = useState('')
  const [errLlm, setErrLlm] = useState('')
  const [lastOk, setLastOk] = useState(null)
  const [now, setNow] = useState(Date.now())

  useEffect(() => {
    if (DEMO) return undefined
    let alive = true
    async function poll() {
      try {
        const body = await fetchRiskPortfolio()
        if (alive) { setSnap(body); setErrSnap(''); setLastOk(Date.now()) }
      } catch (ex) {
        if (alive) setErrSnap(ex.message)
      }
      try {
        const body = await fetchLlmStatus()
        if (alive) { setLlm(body); setErrLlm('') }
      } catch (ex) {
        if (alive) setErrLlm(ex.message)
      }
    }
    poll()
    const t = setInterval(poll, RISK_POLL_MS)
    const tick = setInterval(() => setNow(Date.now()), 1000)
    return () => { alive = false; clearInterval(t); clearInterval(tick) }
  }, [])

  if (DEMO) {
    return (
      <section className="card risk-config-active" aria-label="Risk config aktif">
        <div className="card-head">
          <h2 className="card-title">Risk config aktif</h2>
          <span className="chip" title="Panel ini hanya membaca data broker & settings backend; di mode demo tidak ada sumbernya.">LIVE DATA</span>
        </div>
        <p className="text-faint">
          Nilai plafon risiko dan batas agent dibaca dari settings backend, jadi tidak tersedia di mode demo.
        </p>
      </section>
    )
  }

  const limits = snap?.limits || {}
  const llmRisk = llm?.llm_risk || {}
  const pause = llm?.pause || {}
  const stats = llm?.stats || {}
  const breaches = Array.isArray(snap?.breaches) ? snap.breaches : []
  const stale = lastOk != null && now - lastOk > RISK_STALE_MS
  const dd = llm?.daily_drawdown_pct
  const ddLimit = llmRisk.drawdown_pause_pct

  return (
    <section className={`card risk-config-active ${stale ? 'stale' : ''}`.trim()} aria-label="Risk config aktif">
      <div className="card-head">
        <h2 className="card-title">Risk config aktif</h2>
        <div className="rca-chips">
          <span className={`chip ${limits.enabled === false ? 'chip-down' : 'chip-up'}`} title="portfolio_risk.enabled — gate portofolio dievaluasi di risk gate">
            {limits.enabled === false ? 'GATE OFF' : 'GATE ON'}
          </span>
          <span
            className={`chip ${pause.active ? 'chip-down' : ''}`}
            title={pause.active ? `Agent LLM dipause: ${pause.reason || 'tanpa alasan'} (${pause.source || '—'})` : 'Circuit breaker agent LLM tidak aktif'}
          >
            {pause.active ? 'AGENT PAUSE' : 'AGENT AKTIF'}
          </span>
          {stale && <span className="chip chip-warn">STALE · {Math.round((now - lastOk) / 1000)}s</span>}
        </div>
      </div>

      {!snap && !llm ? (
        <p className="sm-empty">
          {errSnap && errLlm ? `Gagal memuat config risiko: ${errSnap}` : 'Memuat config risiko…'}
        </p>
      ) : (
        <>
          <div className="rca-grid">
            <div className="rca-col">
              <h3 className="rca-sub">
                Plafon portofolio <span className="rca-src num">GET /risk/portfolio · limits</span>
              </h3>
              {errSnap && !snap ? (
                <p className="lifecycle-error" role="alert">{errSnap}</p>
              ) : (
                <dl className="rca-rows">
                  {LIMIT_ROWS.map(([key, label, unit, digits]) => (
                    <RiskRow
                      key={key}
                      label={label}
                      unit={unit}
                      value={fmtNum(limits[key], digits)}
                      hint={`portfolio_risk.${key}`}
                    />
                  ))}
                  <RiskRow
                    label="Simbol diizinkan"
                    value="Tidak terekspos via API"
                    muted
                    hint="allowed_symbols hanya ada di settings backend; butuh endpoint read-only terpisah."
                  />
                  <RiskRow
                    label="Eksposur maks (USD)"
                    value="Tidak terekspos via API"
                    muted
                    hint="exposure_max_usd hanya ada di settings backend; butuh endpoint read-only terpisah."
                  />
                </dl>
              )}
            </div>

            <div className="rca-col">
              <h3 className="rca-sub">
                Batas agent LLM <span className="rca-src num">GET /llm-agent/status · llm_risk</span>
              </h3>
              {errLlm && !llm ? (
                <p className="lifecycle-error" role="alert">{errLlm}</p>
              ) : (
                <>
                  <dl className="rca-rows">
                    {LLM_ROWS.map(([key, label, unit, digits]) => (
                      <RiskRow
                        key={key}
                        label={label}
                        unit={unit}
                        value={fmtNum(llmRisk[key], digits)}
                        hint={`llm_risk.${key}`}
                      />
                    ))}
                    <RiskRow
                      label="Drawdown harian berjalan"
                      unit="%"
                      value={fmtNum(dd, 2)}
                      hint={`daily_drawdown_pct saat ini; pause agent pada ${fmtNum(ddLimit, 1)}%`}
                    />
                    <RiskRow
                      label="Order hari ini / menit ini"
                      value={`${fmtNum(stats.today, 0)} / ${fmtNum(stats.last_minute, 0)}`}
                      hint="stats.today dan stats.last_minute dari llm_order_stats"
                    />
                  </dl>
                  {breaches.length > 0 && (
                    <p className="rca-breach" role="alert" title={breaches.join(' · ')}>
                      {breaches.length} breach aktif: {breaches[0]}
                      {breaches.length > 1 ? ` (+${breaches.length - 1})` : ''}
                    </p>
                  )}
                  {breaches.length === 0 && <p className="rca-clean">Tidak ada breach pada snapshot terakhir.</p>}
                </>
              )}
            </div>
          </div>
          <p className="rca-foot">
            Nilai read-only dari settings efektif (global). Perubahan wajib lewat halaman Guardrail/Ops dengan approval owner + 2FA.
          </p>
        </>
      )}
    </section>
  )
}

